settings = {
    showTalkingIcon = {key="show_talking_icon", value=nil},
    maxVoiceDistance = {key="max_voice_distance", value=nil},
    voiceSoundBoost = {key="voice_sound_boost", value=nil},
}

DEBUG_MODE = false
